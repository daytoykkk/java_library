import modal.MyConnection;


public class testMain {
    public static void main(String[] args) {
        new MyConnection();
    }
}
