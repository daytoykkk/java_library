package modal;

import views.Login;

import java.sql.*;
public class MyConnection {

    Connection connection;
    Statement statement;

    public MyConnection() {
        // 驱动程序名
        String driver = "com.mysql.jdbc.Driver";
        // 指向要访问的数据库名，用户信息等
        String url = "jdbc:mysql://localhost:3306/library";
        String user = "root";
        String password = "daytoykkk";
        // 连接数据库
        try{
            // 加载驱动程序
            Class.forName(driver);
            // 首先用getConnection()连接数据库
            connection = DriverManager.getConnection(url, user, password);
            if(!connection.isClosed()) {
                System.out.println("成功连接到数据库");
                statement = connection.createStatement();
            }

        } catch(ClassNotFoundException e) {
            // 数据库驱动类异常处理
            System.out.println("没找到Driver");
            e.printStackTrace();
        } catch(Exception e) {
            e.printStackTrace();
        }finally {
            new Login(statement);
        }
    }
}
