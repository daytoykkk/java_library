//登陆界面

package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Pattern;

public class Login extends JFrame implements ActionListener {
    JLabel header, nameLabel, title;
    JPanel div, dialog;
    JTextField input;
    JButton loginBtn, cancelBtn;
    Statement statement;
    ResultSet rs;

    public Login(Statement statement) {
        this.statement = statement;
        header = new JLabel(new ImageIcon("image/background.JPG"));
        title = new JLabel("欢迎登陆图书管理系统！",JLabel.CENTER);
        nameLabel = new JLabel("ID：",JLabel.CENTER);
        input = new JTextField();
        loginBtn = new JButton("登陆");
        cancelBtn = new JButton("取消");
        div = new JPanel(new GridLayout(2,2,10,16));
        div.add(nameLabel);
        div.add(input);
        div.add(loginBtn);
        div.add(cancelBtn);

        // 按钮点击事件
        loginBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        setLocationRelativeTo(null);

        this.add(header, "North");
        this.add(div);
        this.setSize(500,350);
        this.setTitle("欢迎界面");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // 登陆
        if(e.getSource() == loginBtn) {
            String id = input.getText().trim();
            if(id.isEmpty()) {      // 输入框判空
                JOptionPane.showMessageDialog(dialog,"用户ID不能为空。", "提示",JOptionPane.WARNING_MESSAGE);
            } else {
                isValidUser(id);
            }
        }

        // 取消
        if(e.getSource() == cancelBtn) {
            this.dispose();
        }
    }

    public void isValidUser(String id) {        // 判断用户登录，成功跳转到个人主页
        if(!isInteger(id)) {
            JOptionPane.showMessageDialog(dialog,"很抱歉，没有这个用户。", "提示",JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            String sql = "select * from reader where ReaderID=" + id;
            rs = statement.executeQuery(sql);
            if(rs.next()) {
                String name = rs.getString("LastName") + rs.getString("FirstName");
                String readerId = rs.getString("ReaderID");
                new Home(readerId, name, statement);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog,"很抱歉，没有这个用户。", "提示",JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static boolean isInteger(String str) {
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        return pattern.matcher(str).matches();
    }
}
