//搜索页面

package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Statement;

public class Search extends JFrame implements ActionListener{

    JLabel h1;
    JLabel isbnLabel,titleLabel,authorLabel,publisherLabel,dateLabel,typeLabel,warnLabel;
    JTextField isbnInput,titleInput,authorInput,publisherInput,dateInput,typeInput;
    JButton btn;
    Statement statement;
    String readerId;

    public  Search(String readerId, Statement statement) {
        this.readerId = readerId;
        this.statement = statement;

        showView();
        btn.addActionListener(this);

        setLocationRelativeTo(null);

        this.setSize(500,600);
        this.setTitle("搜索图书");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    // 静态界面
    public void showView() {
        h1 = new JLabel("请输入要搜索的图书");
        h1.setFont(new java.awt.Font("Dialog",1,20));
        isbnLabel = new JLabel("ISBN：");
        titleLabel = new JLabel("书名：");
        authorLabel = new JLabel("作者：");
        publisherLabel = new JLabel("出版社：");
        dateLabel = new JLabel("出版日期：");
        typeLabel = new JLabel("类型：");
        warnLabel = new JLabel("日期格式：xxxx年xx月xx日");
        isbnInput = new JTextField();
        titleInput = new JTextField();
        authorInput = new JTextField();
        publisherInput = new JTextField();
        dateInput = new JTextField();
        typeInput = new JTextField();
        btn = new JButton("搜索");

        GridBagLayout gbl = new GridBagLayout();
        this.setLayout(gbl);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;

        // h1
        gbc.gridx=0;gbc.gridy=0;gbc.gridwidth=7;gbc.gridheight=1;
        gbl.setConstraints(h1, gbc);

        // isbn
        gbc.gridx=0;gbc.gridy=1;gbc.gridwidth=3;gbc.gridheight=1;
        gbl.setConstraints(isbnLabel, gbc);

        gbc.gridx=3;gbc.gridy=1;gbc.gridwidth=4;gbc.gridheight=1;
        gbl.setConstraints(isbnInput, gbc);

        // title
        gbc.gridx=0;gbc.gridy=2;gbc.gridwidth=3;gbc.gridheight=1;
        gbl.setConstraints(titleLabel, gbc);

        gbc.gridx=3;gbc.gridy=2;gbc.gridwidth=4;gbc.gridheight=1;
        gbl.setConstraints(titleInput, gbc);

        // author
        gbc.gridx=0;gbc.gridy=3;gbc.gridwidth=3;gbc.gridheight=1;
        gbl.setConstraints(authorLabel, gbc);

        gbc.gridx=3;gbc.gridy=3;gbc.gridwidth=4;gbc.gridheight=1;
        gbl.setConstraints(authorInput, gbc);

        // 出版社
        gbc.gridx=0;gbc.gridy=4;gbc.gridwidth=3;gbc.gridheight=1;
        gbl.setConstraints(publisherLabel, gbc);

        gbc.gridx=3;gbc.gridy=4;gbc.gridwidth=4;gbc.gridheight=1;
        gbl.setConstraints(publisherInput, gbc);

        // 类型
        gbc.gridx=0;gbc.gridy=5;gbc.gridwidth=3;gbc.gridheight=1;
        gbl.setConstraints(typeLabel, gbc);

        gbc.gridx=3;gbc.gridy=5;gbc.gridwidth=4;gbc.gridheight=1;
        gbl.setConstraints(typeInput, gbc);

        // 日期
        gbc.gridx=0;gbc.gridy=6;gbc.gridwidth=3;gbc.gridheight=1;
        gbl.setConstraints(dateLabel, gbc);

        gbc.gridx=3;gbc.gridy=6;gbc.gridwidth=4;gbc.gridheight=1;
        gbl.setConstraints(dateInput, gbc);

        // 按钮
        gbc.gridx=0;gbc.gridy=8;gbc.gridwidth=7;gbc.gridheight=1;
        gbl.setConstraints(btn, gbc);

        // 提示
        gbc.gridx=0;gbc.gridy=7;gbc.gridwidth=7;gbc.gridheight=1;
        gbl.setConstraints(warnLabel, gbc);


        this.add(h1);
        this.add(isbnLabel);
        this.add(isbnInput);
        this.add(titleLabel);
        this.add(titleInput);
        this.add(authorLabel);
        this.add(authorInput);
        this.add(publisherLabel);
        this.add(publisherInput);
        this.add(typeLabel);
        this.add(typeInput);
        this.add(dateLabel);
        this.add(dateInput);
        this.add(btn);
        this.add(warnLabel);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btn) {
            // 处理sql语句
            String isbn = isbnInput.getText().trim();
            String title = titleInput.getText().trim();
            String author = authorInput.getText().trim();
            String publisher = publisherInput.getText().trim();
            String date = dateInput.getText().trim();
            String type = typeInput.getText().trim();

            if(isbn.isEmpty()&&title.isEmpty()&&author.isEmpty()&&publisher.isEmpty()&&date.isEmpty()&&type.isEmpty()) {
                JOptionPane.showMessageDialog(this,"请输入关键词。", "提示",JOptionPane.ERROR_MESSAGE);
            }

            String sql = "SELECT *\n" +
                    "FROM\n" +
                    "\tbooks\n" +
                    "WHERE\n";
                    sql += isbn.isEmpty() ? "":("books.ISBN = \"" + isbn + "\" and ");
                    sql += title.isEmpty() ? "":("books.Title = \"" + title + "\" and ");
                    sql += author.isEmpty() ? "":("books.Author = \"" + author + "\" and ");
                    sql += publisher.isEmpty() ? "":("books.Publisher = \"" + publisher + "\" and ");
                    sql += date.isEmpty() ? "":("books.PublicationDate = \"" + date + "\" and ");
                    sql += type.isEmpty() ? "":("books.Type = \"" + type + "\" and ");

            sql = sql.substring(0,sql.length()-5);
            new ResultTable(readerId,sql,statement);
        }
    }
}
