// 搜索后的表格

package views;

import javax.swing.*;
import javax.swing.plaf.nimbus.State;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.*;

public class ResultTable extends JFrame implements MouseListener {

    Statement statement;
    String readerId,sql;
    JTable table;
    JScrollPane jsp;


    static Object[] columns = {"书名","ISBN","作者","出版社","版本","出版日期","类型","操作"};
    static Object[][] data = null;

    public ResultTable(String readerId, String sql, Statement statement) {
        this.readerId = readerId;
        this.sql = sql;
        this.statement = statement;

        // 获取图书数据
        getMsg();
        DefaultTableModel model = new DefaultTableModel(data, columns){
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);
        table.setRowHeight(40);
        RowSorter sorter = new TableRowSorter(model);
        table.setRowSorter(sorter);
        table.addMouseListener(this);
        jsp = new JScrollPane(table);

        setLocationRelativeTo(null);


        this.add(jsp);
        this.setSize(500,350);
        this.setTitle("查询结果");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    // 获取图书数据
    public void getMsg() {
        try {
            ResultSet rs = statement.executeQuery(sql);
//            ResultSetMetaData md = rs.getMetaData();
            int cnt=0;
            if(rs.next()) {
                cnt++;
            } else return;
            while(rs.next()) cnt++;
            rs.beforeFirst();
            data = new Object[cnt][8];
            int i=0;
            while(rs.next()) {
                data[i][0] = rs.getString("Title");
                data[i][1] = rs.getString("ISBN");
                data[i][2] = rs.getString("Author");
                data[i][3] = rs.getString("Publisher");
                data[i][4] = rs.getString("EditionNumber");
                data[i][5] = rs.getString("PublicationDate");
                data[i][6] = rs.getString("Type");
                data[i][7] = "点我借书";
                i++;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 借书
    @Override
    public void mouseClicked(MouseEvent e) {
        int row = table.getSelectedRow();
        if(table.getValueAt(row,1)==null) return;   //判空
        String isbn = (String) data[row][1];
        String title = (String) data[row][0];
        int opt = JOptionPane.showConfirmDialog(this,
                "是否借书《" + title + "》？", "确认信息",
                JOptionPane.YES_NO_OPTION);
        if (opt == JOptionPane.YES_OPTION) {
            // 检查是否被借出
            if(isBorrowed(isbn)) return;
            // 检查用户可不可以借书
            if(!haveLimitNumber(readerId)) return;
            // 借书，数据库增加一条记录，用户的Limit-1
            borrowBook(isbn);

        }
    }

    // 图书是否被借出
    public boolean isBorrowed(String isbn) {
        String sql = "SELECT\n" +
                "\trecord.ReturnDate as time\n" +
                "FROM\n" +
                "\trecord\n" +
                "WHERE\n" +
                "\trecord.ISBN = " + isbn;
        try {
            ResultSet rs = statement.executeQuery(sql);
            if(rs.next()) {     //已经被借出了
                String time = rs.getString("time");
                JOptionPane.showMessageDialog(this,"该书已被借出，归还时间" + time, "提示",JOptionPane.ERROR_MESSAGE);
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // 用户是否可以借书
    public boolean haveLimitNumber(String readerId) {
        String sql = "SELECT\n" +
                "\treader.LimitNumber as number\n" +
                "FROM\n" +
                "\treader\n" +
                "WHERE\n" +
                "\treader.ReaderID = " + readerId;
        try {
            ResultSet rs = statement.executeQuery(sql);
            if(rs.next()){
                int num = Integer.parseInt(rs.getString("number"));
                if(num <= 0) {  //不能借了
                    JOptionPane.showMessageDialog(this,"已超过您的最大借阅数目", "提示",JOptionPane.ERROR_MESSAGE);
                    return false;
                } else {
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // 借书
    public void borrowBook(String isbn) {
        // 借书、还书时间 now/after
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String now = sdf.format(date);
        Calendar ca = Calendar.getInstance();
        ca.setTime(date);
        ca.add(Calendar.DATE,5);
        date = ca.getTime();
        String after = sdf.format(date);
        String recordId = isbn + readerId;

        String sql = "insert into record values(" + recordId + "," + isbn + "," + readerId + ",'" + now + "','" + after + "');";
        String subLimitSql = "update reader set LimitNumber = LimitNumber-1 where ReaderID=" + readerId + ";";
        try {
            statement.executeUpdate(sql);
            statement.executeUpdate(subLimitSql);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JOptionPane.showMessageDialog(this,"借书成功。");
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
