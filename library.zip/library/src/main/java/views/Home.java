//个人界面： 搜索书籍按钮、我的借书情况表格
//搜索书籍按钮点击去搜索页面，借书情况表格点击去还书详情页

package views;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Home extends JFrame implements MouseListener, ActionListener {

    Statement statement;
    String readerId,name;
    JButton btn;
    JTable table;
    JPanel div;
    JScrollPane jsp;

    static Object[] columns = {"书名","ISBN","借书时间","还书时间","操作"};
    static Object[][] data = new Object[2][5];

    public Home (String id, String name, Statement statement){
        this.statement = statement;
        this.readerId = id;
        this.name = name;

        btn = new JButton("搜索图书");
        btn.setPreferredSize(new Dimension(100,40));
        btn.addActionListener(this);

        div = new JPanel();
        div.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        div.add(btn);

        // 获取借书数据并渲染到table
        getBorrowMsg();
        DefaultTableModel model = new DefaultTableModel(data, columns){
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);
        table.setRowHeight(40);
        table.addMouseListener(this);
        jsp = new JScrollPane(table);

        setLocationRelativeTo(null);

        this.add(div, "North");
        this.add(jsp);
        this.setSize(500,350);
        this.setTitle(name + "的图书馆");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    // 获取借书情况
    public void getBorrowMsg() {
        String sql = "SELECT\n" +
                "\trecord.BorrowingDate as BorrowingDate, \n" +
                "\trecord.ReturnDate as ReturnDate, \n" +
                "\tbooks.ISBN as ISBN, \n" +
                "\tbooks.Title as title\n" +
                "FROM\n" +
                "\trecord,\n" +
                "\tbooks\n" +
                "WHERE\n" +
                "\trecord.ReaderID = " + readerId + " AND\n" +
                "\trecord.ISBN = books.ISBN";

        try {
            ResultSet rs = statement.executeQuery(sql);
            int i = 0;
            while(rs.next()) {
                data[i][0] = rs.getString("title");
                data[i][1] = rs.getString("ISBN");
                data[i][2] = rs.getString("BorrowingDate");
                data[i][3] = rs.getString("ReturnDate");
                data[i][4] = "点我还书";
                i++;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    // 更新table数据
    public void refreshTable() {
        DefaultTableModel model = new DefaultTableModel(data, columns){
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table.setModel(model);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btn) {
            new Search(readerId, statement);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int row = table.getSelectedRow();
        if(table.getValueAt(row,1)==null) return;   //判空
        String isbn = (String) data[row][1];
        String title = (String) data[row][0];
        int opt = JOptionPane.showConfirmDialog(this,
                "是否归还图书《" + title + "》？", "确认信息",
                JOptionPane.YES_NO_OPTION);
        if (opt == JOptionPane.YES_OPTION) {
            String delSql = "delete from record where ISBN=" + isbn + ";";
            String addLimitSql = "update reader set LimitNumber = LimitNumber+1 where ReaderID=" + readerId + ";";
            try {
                statement.executeUpdate(delSql);
                statement.executeUpdate(addLimitSql);
            } catch (SQLException err) {
                err.printStackTrace();
            }finally {
                data[row]= new Object[]{};
                JOptionPane.showMessageDialog(this,"还书成功。");
                refreshTable();
            }

        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }


}
